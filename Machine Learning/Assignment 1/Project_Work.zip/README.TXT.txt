Wine Quality Prediction

Overview
This project predicts the quality of wine using machine learning models. It employs Random Forest and Support Vector Machine (SVM) classifiers with techniques to address data imbalance using SMOTE. The final model is evaluated based on the F1 Score for its ability to balance precision and recall.

Dataset
Source: UC Irvine Machine Learning Repository
Name: winequality-red.csv
Features: 12 (chemical properties of wine such as acidity, alcohol, pH)
Target: Binary classification (Good = 1, Bad = 0)
Steps in the Code
1. Data Preparation
Load Dataset: The dataset is loaded and checked for class distribution.
Target Transformation: The quality column is converted into a binary classification.
Train-Test Split: Data is split into 80% training and 20% testing with stratification.
2. Data Preprocessing
Standardization: Features are scaled using StandardScaler to improve model performance.
Imbalanced Data Handling: SMOTE is applied to balance the training dataset by oversampling the minority class.
3. Model Training
Two classifiers are trained using Repeated K-Fold Cross-Validation:
Random Forest
SVM (RBF Kernel)
4. Model Evaluation
Evaluation metrics include:
Accuracy
Precision
Recall
F1 Score
Cross-validation results are computed for both models.
The model with the highest F1 Score is selected as the best-performing classifier.
5. Final Model
After balancing the dataset with SMOTE:
The best-performing model is retrained on the resampled data.
Its performance is evaluated on the test set using a classification report and confusion matrix.


Dependencies
This project requires the following Python libraries:

pandas
numpy
matplotlib
seaborn
scikit-learn
imbalanced-learn
scipy
IPython


How to Run
Place the winequality-red.csv file in the same directory as the script.

Install required dependencies using:
pip install pandas numpy matplotlib seaborn scikit-learn imbalanced-learn scipy

Run the script:
python wine_quality_prediction.py