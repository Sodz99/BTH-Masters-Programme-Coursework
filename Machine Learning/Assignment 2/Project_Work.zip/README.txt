--------------
Project Title
--------------
Experimental Performance Analysis of Supervised Learning Algorithms using Friedman and Nemenyi Tests

--------------
Overview
--------------
This project evaluates the computational and predictive performance of three supervised learning algorithms—Logistic Regression, Random Forest, and SVM—on the Spambase Dataset.
The evaluation is performed using training time, accuracy, and F1-score.
The Friedman test and Nemenyi test are used to statistically compare the classifiers' results.

The project is executed in Jupyter Notebook for better clarity and visualization.

--------------
Requirements
--------------
Python Version:

Python 3.8 or higher

Required Libraries:
Install the necessary libraries using the command below in the terminal or Jupyter Notebook:

command
pip install numpy pandas scikit-learn notebook

--------------
Dataset
--------------
Download the Spambase dataset from the UCI Machine Learning Repository.
https://archive.ics.uci.edu/ml/datasets/Spambase

Save the file as spambase.data in the same folder as the notebook.

--------------
Folder Structure
--------------
Ensure the following structure:

Project_Folder/
│-- spambase.data             
│-- Sohan_Arun.ipynb  
│-- README.txt                

--------------
Execution Instructions
--------------
Open Jupyter Notebook:
Run the following command in your terminal or command prompt:

jupyter notebook
Open the Project Notebook:

Navigate to the project folder using the Jupyter Notebook interface.
Open the file Sohan_Arun.ipynb.

Run the Notebook:
Run each cell in the notebook sequentially by pressing Shift + Enter.

The notebook will perform the following steps:
Load the Spambase dataset.
Perform 10-Fold Cross-Validation to evaluate training time, accuracy, and F1-score for the three algorithms:
Logistic Regression
Random Forest
SVM
Conduct the Friedman Test to check for significant differences.
If significant, perform the Nemenyi Test for pairwise comparisons.
Display results in neatly formatted tables, including ranks and statistical test outcomes.

--------------
Results
--------------
Results will be displayed in the notebook, 
including:
Performance tables for each fold and metric.
Average ranks of classifiers.
Friedman test statistics and significance results.
Nemenyi test pairwise comparisons, if applicable.


Example Output
-----------------------------------------------------------------------
| Data set | LogisticRegression    | RandomForest        | SVM        |
-----------------------------------------------------------------------
| 1        | 1.1349 (3)            | 0.3764 (2)          | 0.2295 (1) |
| 2        | 1.1886 (3)            | 0.3736 (2)          | 0.2556 (1) |
...
-----------------------------------------------------------------------
| avg rank | 3.0                   | 1.9                 | 1.1        |
-----------------------------------------------------------------------

Friedman statistic: 20.0000, df=2
The Friedman test is significant at alpha=0.05 (chi-square=20.0000 > 7.8).


--------------
Troubleshooting
--------------
Dataset not found error:

Ensure that spambase.data is saved in the same directory as the notebook.
Jupyter Notebook not installed:

Install it using:
pip install notebook

ModuleNotFoundError:
Install missing libraries by running this command in a notebook cell or terminal:
pip install numpy pandas scikit-learn

Python version issue:
Ensure Python 3.8 or higher is installed. Verify using:
python --version


--------------
Contact
--------------
For any questions or issues, please contact:
Sohan Arun
Email: sohanoffice46@gmail.com